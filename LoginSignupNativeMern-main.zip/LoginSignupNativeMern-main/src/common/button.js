module.exports = {
    button1: {
        backgroundColor: '#F50057',
        color: '#fff',
        padding: 10,
        borderRadius: 5,
        fontSize: 20,
        minWidth: 150,
        textAlign: 'center',
        margin: 10,
    }
}